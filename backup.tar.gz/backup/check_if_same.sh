#!/usr/bin/bash
for i in {1..8}; do
  local_sum=`gfal-sum  dataMB${i}_pPb_pT2to3.root  ADLER32 | cut -d ' ' -f 2`
  remote_sum=`gfal-sum root://cmseos.fnal.gov///store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_pPb/dataMB${i}_pPb_pT2to3.root ADLER32 | cut -d ' ' -f 2`
  #echo $local_sum
  #echo $remote_sum
  if [[ $local_sum == $remote_sum ]]; then
    echo "dataMB${i}_pPb True $local_sum"
  fi
done

for i in {1..20}; do
  local_sum=`gfal-sum  dataMB${i}_Pbp_pT2to3.root  ADLER32 | cut -d ' ' -f 2`
  remote_sum=`gfal-sum root://cmseos.fnal.gov///store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/dataMB${i}_Pbp_pT2to3.root ADLER32 | cut -d ' ' -f 2`
  #echo $local_sum
  #echo $remote_sum
  if [[ $local_sum == $remote_sum ]]; then
    echo "dataMB${i}_Pbp True $local_sum"
  fi
done
