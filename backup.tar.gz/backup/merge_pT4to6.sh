#!/usr/bin/bash
# for i in {1..3}; do
#   hadd dataHM${i}_pPb_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_pPb/pT_4.0_6.0) &> dataHM${i}_pPb_pT4to6.log
#   echo "Done dataHM${i}_pPb_pT4to6.root"
# done

# for i in {4..5}; do
#   hadd dataHM${i}_pPb_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_pPb/pT_4.0_6.0) &> dataHM${i}_pPb_pT4to6.log
#   echo "Done dataHM${i}_pPb_pT4to6.root"
# done

#for i in 6; do
#  hadd dataHM${i}_pPb_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_pPb/pT_4.0_6.0) &> dataHM${i}_pPb_pT4to6.log
#  echo "Done dataHM${i}_pPb_pT4to6.root"
#done

# for i in {1..3}; do
#   hadd dataHM${i}_Pbp_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_Pbp/pT_4.0_6.0) &> dataHM${i}_Pbp_pT4to6.log
#   echo "Done dataHM${i}_Pbp_pT4to6.root"
# done

for i in {4..6}; do
  hadd dataHM${i}_Pbp_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_Pbp/pT_4.0_6.0) &> dataHM${i}_Pbp_pT4to6.log
  echo "Done dataHM${i}_Pbp_pT4to6.root"
done
