#!/usr/bin/env python
import ROOT
import os
import sys
import subprocess

oldpath = ROOT.gROOT.GetMacroPath()
newpath = oldpath +  ":" + os.environ.get("OPENHF2020TOP") + "/PromptExtraction"
ROOT.gROOT.SetMacroPath(newpath)
ROOT.gROOT.LoadMacro("skimToHistsMC.C")

isMC = True
pTMin = 4.0
pTMax = 6.0

pTMinStr = "%.1f" % pTMin
pTMinStr = pTMinStr.replace(".", "p")
pTMaxStr = "%.1f" % pTMax
pTMaxStr = pTMaxStr.replace(".", "p")

pTLabel = 'pT%s_%s' % (pTMinStr, pTMaxStr)

conf = ROOT.Conf()
conf._treeName = "lambdacAna/ParticleNTuple" if not isMC else "lambdacAna_mc/ParticleNTuple"
conf._outDir =  'MC'
conf._mvaCut = 0.0029
conf._reweight = False
conf._mvaName = "MLP4to6MBNp2N_noDR"

boost = "pPb"
trig = 'Prompt'
dsLabel = '%s_%s' % (trig, boost)
conf._inFileList = "Prompt.list"

conf._ofile = "dca_%s_%s.root" % (dsLabel, pTLabel)
conf._commonCuts = "isPrompt"
conf._commonCuts = ""
conf._label = '_data' + trig + '_' + pTLabel

if not os.path.exists(conf._outDir):
    mypath = str(conf._outDir)
    if mypath.find("root://") < 0:
        #print("Not xrootd")
        os.mkdir(conf._outDir)
ROOT.skimToHists(conf)

trig = 'NonPrompt'
dsLabel = '%s_%s' % (trig, boost)
conf._inFileList = "Nonprompt.list"
conf._commonCuts = "!isPrompt"

conf._ofile = "dca_%s_%s.root" % (dsLabel, pTLabel)
conf._commonCuts = ""
conf._label = '_data' + trig + '_' + pTLabel

if not os.path.exists(conf._outDir):
    mypath = str(conf._outDir)
    if mypath.find("root://") < 0:
        #print("Not xrootd")
        os.mkdir(conf._outDir)
ROOT.skimToHists(conf)
