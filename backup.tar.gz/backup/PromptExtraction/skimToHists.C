struct Conf
{
  std::string _inFileList;
  std::string _treeName;
  std::string _outDir;
  std::string _ofile;
  std::string _commonCuts;
  std::string _label;
  std::string _mvaName;
  double _mvaCut;
  bool _reweight;
  Conf(): _mvaCut(-1), _reweight(false) {}
};

void skimToHists(Conf conf)
{
  ROOT::EnableImplicitMT();
  gROOT->SetBatch(kTRUE);
  // 
  auto inFileList = conf._inFileList;
  auto treeName = conf._treeName;
  auto outDir = conf._outDir.size() ? conf._outDir + "/" : ".";
  auto ofile = conf._ofile;
  auto reweight = conf._reweight;
  auto commonCuts = conf._commonCuts;
  auto label = conf._label;
  auto mvaCut = conf._mvaCut;
  auto mvaName = conf._mvaName;

  TFile* outputFile = TFile::Open((outDir+"/"+ofile).c_str(), "recreate");


  double xDCASigBins[] = {0.05, 0.1, 0.2, 0.4, 0.65, 1.0, 1.5, 2.5};
  const int nDCASigBins = sizeof(xDCASigBins)/sizeof(double) - 1;
  double xDCABins[] = {0.02, 0.04, 0.07, 0.1, 0.15};
  const int nDCABins = sizeof(xDCABins)/sizeof(double) - 1;
  TH1D hDCASig3D(Form("hDCASig3D%s", label.c_str()),
                 Form("%s;DCASig3D;events", label.c_str()),
                 nDCASigBins, xDCASigBins);
  TH1D hDCA3D(Form("hDCA3D%s", label.c_str()),
              Form("%s;DCA3D;events", label.c_str()),
              nDCABins, xDCABins);

  const int nMass = 100;
  double massBins[nMass+1];
  const double step = (2.465-2.135)/nMass;
  for (int i=0; i< (nMass+1); ++i) {
    massBins[i] = 2.135 + i * step;
  }
  TH2D hDCASig3DVsMass(Form("hDCASig3DVsMass%s", label.c_str()),
                       Form("%s;Mass;DCASig3D;events", label.c_str()),
                       nMass, massBins, nDCASigBins, xDCASigBins);
  TH2D hDCA3DVsMass(Form("hDCA3DVsMass%s", label.c_str()),
                    Form("%s;Mass;DCA3D;events", label.c_str()),
                    nMass, massBins, nDCASigBins, xDCASigBins);

  TH1D hMass(Form("hMass%s", label.c_str()),
             Form("%s;Mass;events", label.c_str()), nMass, massBins);

  if (reweight) TH1::SetDefaultSumw2(kTRUE);

  std::vector<std::string> files;
  std::ifstream infiles(inFileList.c_str());
  for (std::string str; std::getline(infiles, str, '\n'); ) {
    if (str.at(0) == '#') continue;
    if (str.find("ws") != std::string::npos) continue;
    //cout << str << endl;
    files.push_back(str);
  }
  files.shrink_to_fit();

  auto df = ROOT::RDataFrame(treeName, files);

  std::string cuts;
  if (commonCuts.size()) {
    cuts = "( " + commonCuts + " )";
  }
  if (cuts.size()) {
    cuts += Form(" && %s > %g", mvaName.c_str(), mvaCut);
  } else {
    cuts = Form("%s > %g", mvaName.c_str(), mvaCut);
  }
  auto dfSkim = df.Filter(cuts);
  auto DCALambdaFunc = [](float x, float y) ->
                       float { return x * std::sin(y); };
  auto DCASigLambdaFunc = [](float x, float y, float z) ->
                          float { return x / y * std::sin(z); };
  auto dfNew = dfSkim.Define("DCA3D", DCALambdaFunc,
                             {"cand_decayLength3D", "cand_angle3D"})
                     .Define("DCASig3D", DCASigLambdaFunc,
                             {"cand_decayLength3D", "cand_decayLengthError3D",
                             "cand_angle3D"});
  ROOT::RDF::RResultPtr<TH1D> histDCA, histDCASig, histMass;
  ROOT::RDF::RResultPtr<TH2D> histDCAVsMass, histDCASigVsMass;
  if (reweight) {
    histDCA = dfNew.Histo1D(hDCA3D, "DCA3D", "eventWeight");
    histDCASig = dfNew.Histo1D(hDCA3D, "DCASig3D", "eventWeight");
    histMass = dfNew.Histo1D(hMass, "cand_mass", "eventWeight");
    histDCAVsMass = dfNew.Histo2D(hDCA3DVsMass, "cand_mass", "DCA3D",
                                  "eventWeight");
    histDCASigVsMass = dfNew.Histo2D(hDCASig3DVsMass, "cand_mass", "DCASig3D",
                                     "eventWeight");
  } else {
    histDCA = dfNew.Histo1D(hDCA3D, "DCA3D");
    histDCASig = dfNew.Histo1D(hDCA3D, "DCASig3D");
    histMass = dfNew.Histo1D(hMass, "cand_mass");
    histDCAVsMass = dfNew.Histo2D(hDCA3DVsMass, "cand_mass", "DCA3D");
    histDCASigVsMass = dfNew.Histo2D(hDCASig3DVsMass, "cand_mass", "DCASig3D");
  }

  outputFile->cd();
  histDCA->Write();
  histDCASig->Write();
  histMass->Write();
  histDCAVsMass->Write();
  histDCASigVsMass->Write();
  outputFile->Close();
}
