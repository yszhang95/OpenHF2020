#!/usr/bin/env python
import ROOT
import os
import sys
import subprocess

oldpath = ROOT.gROOT.GetMacroPath()
newpath = oldpath +  ":" + os.environ.get("OPENHF2020TOP") + "/PromptExtraction"
ROOT.gROOT.SetMacroPath(newpath)
ROOT.gROOT.LoadMacro("skimToHists.C")

isMC = False
pTMin = 4.0
pTMax = 6.0

pTMinStr = "%.1f" % pTMin
pTMinStr = pTMinStr.replace(".", "p")
pTMaxStr = "%.1f" % pTMax
pTMaxStr = pTMaxStr.replace(".", "p")

trig = 'MB'
pd = 1
boost = 'pPb'

pds = {"pPb" : [1, 2, 3, 4, 5, 6, 8], "Pbp" : [1, 3, 4, 5, 6, 7, 9]}

for boost in ["pPb", "Pbp"]:
  for pd in pds[boost]:
    print("Started data%s%d_%s" % (trig, pd, boost))

    dsLabel = 'data%s%d_%s' % (trig, pd, boost)
    pTLabel = 'pT%s_%s' % (pTMinStr, pTMaxStr)

    filelist = open(dsLabel + '_' + pTLabel + '.list', 'w')
    searchpath = '/store/user/yousen//RiceHIN/OpenHF2020_LamCKsP/AppMVA/%s/pT_%.1f_%.1f' % (dsLabel, pTMin, pTMax)
    subprocess.run(['xrdfs', 'root://cmseos.fnal.gov', 'ls', '-u', searchpath], stdout=filelist)

    conf = ROOT.Conf()
    conf._inFileList = filelist.name
    conf._treeName = "lambdacAna/ParticleNTuple" if not isMC else "lambdacAna_mc/ParticleNTuple"
    #conf._outDir = "root://cmseos.fnal.gov//store/user/yousen//RiceHIN/OpenHF2020_LamCKsP/AppMVA/dataMB1_pPb/Merged"
    conf._outDir =  'data%s'  % (trig)
    conf._ofile = "dca_%s_%s.root" % (dsLabel, pTLabel)
    conf._commonCuts = ""
    #conf._label = '_' + dsLabel + '_' + pTLabel
    conf._label = '_data' + trig + '_' + pTLabel
    conf._mvaCut = 0.0029
    conf._reweight = False
    conf._mvaName = "MLP4to6MBNp2N_noDR"

    if not os.path.exists(conf._outDir):
      mypath = str(conf._outDir)
      if mypath.find("root://") < 0:
        #print("Not xrootd")
        os.mkdir(conf._outDir)

    ROOT.skimToHists(conf)

    filelist.close()

    print("Finished", "%s/%s" % (conf._outDir, conf._ofile))
