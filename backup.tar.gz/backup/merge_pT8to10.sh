#!/usr/bin/bash

# for i in {1..3}; do
#   hadd dataHM${i}_pPb_pT8to10.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_pPb/pT_8.0_10.0) &> dataHM${i}_pPb_pT8to10.log
#   echo "Done dataHM${i}_pPb_pT8to10.root"
# done

# for i in {4..6}; do
#   hadd dataHM${i}_pPb_pT8to10.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_pPb/pT_8.0_10.0) &> dataHM${i}_pPb_pT8to10.log
#   echo "Done dataHM${i}_pPb_pT8to10.root"
# done

# for i in {1..3}; do
#   hadd dataHM${i}_Pbp_pT8to10.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_Pbp/pT_8.0_10.0) &> dataHM${i}_Pbp_pT8to10.log
#   echo "Done dataHM${i}_Pbp_pT8to10.root"
# done

for i in {4..6}; do
  hadd dataHM${i}_Pbp_pT8to10.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_Pbp/pT_8.0_10.0) &> dataHM${i}_Pbp_pT8to10.log
  echo "Done dataHM${i}_Pbp_pT8to10.root"
done

