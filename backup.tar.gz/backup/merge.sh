#!/usr/bin/bash
#for i in {2..8}; do
#  hadd dataMB${i}_pPb_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_pPb/pT_4.0_6.0) &> dataMB${i}_pPb_pT4to6.log
#done

#for i in {1..3}; do
#  hadd dataMB${i}_Pbp_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_4.0_6.0) &> dataMB${i}_Pbp_pT4to6.log
#done

#for i in {4..6}; do
#  hadd dataMB${i}_Pbp_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_4.0_6.0) &> dataMB${i}_Pbp_pT4to6.log
#done

#for i in {7..9}; do
#  hadd dataMB${i}_Pbp_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_4.0_6.0) &> dataMB${i}_Pbp_pT4to6.log
#done

#for i in {10..12}; do
#  hadd dataMB${i}_Pbp_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_4.0_6.0) &> dataMB${i}_Pbp_pT4to6.log
#done

#for i in {13..15}; do
#  hadd dataMB${i}_Pbp_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_4.0_6.0) &> dataMB${i}_Pbp_pT4to6.log
#done

#for i in 14; do
#  hadd dataMB${i}_Pbp_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_4.0_6.0) &> dataMB${i}_Pbp_pT4to6.log
#done

#for i in 20; do
#  hadd dataMB${i}_Pbp_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_4.0_6.0) &> dataMB${i}_Pbp_pT4to6.log
#done

#for i in 16; do
#  hadd dataMB${i}_Pbp_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_4.0_6.0) &> dataMB${i}_Pbp_pT4to6.log
#done

#for i in {17..19}; do
#  hadd dataMB${i}_Pbp_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_4.0_6.0) &> dataMB${i}_Pbp_pT4to6.log
#done

## 2 to 3
#for i in {1..2}; do
#  hadd dataMB${i}_pPb_pT2to3.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_pPb/pT_2.0_3.0) &> dataMB${i}_pPb_pT2to3.log
#done

#for i in {3..5}; do
#  hadd dataMB${i}_pPb_pT2to3.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_pPb/pT_2.0_3.0) &> dataMB${i}_pPb_pT2to3.log
#done

#for i in {6..8}; do
#  hadd dataMB${i}_pPb_pT2to3.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_pPb/pT_2.0_3.0) &> dataMB${i}_pPb_pT2to3.log
#  echo "Done dataMB${i}_pPb_pT2to3.root"
#done

#for i in {1..3}; do
#  hadd dataMB${i}_Pbp_pT2to3.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_2.0_3.0) &> dataMB${i}_Pbp_pT2to3.log
#  echo "Done dataMB${i}_Pbp_pT2to3.root"
#done

#for i in {4..6}; do
#  hadd dataMB${i}_Pbp_pT2to3.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_2.0_3.0) &> dataMB${i}_Pbp_pT2to3.log
#  echo "Done dataMB${i}_Pbp_pT2to3.root"
#done

#for i in {7..9}; do
#  hadd dataMB${i}_Pbp_pT2to3.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_2.0_3.0) &> dataMB${i}_Pbp_pT2to3.log
#  echo "Done dataMB${i}_Pbp_pT2to3.root"
#done

#for i in {10..12}; do
#  hadd dataMB${i}_Pbp_pT2to3.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_2.0_3.0) &> dataMB${i}_Pbp_pT2to3.log
#  echo "Done dataMB${i}_Pbp_pT2to3.root"
#done

#for i in {13..15}; do
#  hadd dataMB${i}_Pbp_pT2to3.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_2.0_3.0) &> dataMB${i}_Pbp_pT2to3.log
#  echo "Done dataMB${i}_Pbp_pT2to3.root"
#done

#for i in {16..17}; do
#  hadd dataMB${i}_Pbp_pT2to3.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_2.0_3.0) &> dataMB${i}_Pbp_pT2to3.log
#  echo "Done dataMB${i}_Pbp_pT2to3.root"
#done

#for i in {18..20}; do
#  hadd dataMB${i}_Pbp_pT2to3.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_2.0_3.0) &> dataMB${i}_Pbp_pT2to3.log
#  echo "Done dataMB${i}_Pbp_pT2to3.root"
#done

#for i in 5 18 ; do
#  hadd dataMB${i}_Pbp_pT2to3.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_2.0_3.0) &> dataMB${i}_Pbp_pT2to3.log
#  echo "Done dataMB${i}_Pbp_pT2to3.root"
#done

#for i in {1..8} ; do
#  hadd dataMB${i}_Pbp_pT8to10.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_8.0_10.0) &> dataMB${i}_Pbp_pT8to10.log
#  echo "Done dataMB${i}_Pbp_pT8to10.root"
#done

#for i in {1..3} ; do
#  hadd dataMB${i}_Pbp_pT8to10.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_8.0_10.0) &> dataMB${i}_Pbp_pT8to10.log
#  echo "Done dataMB${i}_Pbp_pT8to10.root"
#done


#for i in {1..8} ; do
#  hadd dataMB${i}_pPb_pT8to10.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_pPb/pT_8.0_10.0) &> dataMB${i}_pPb_pT8to10.log
#  echo "Done dataMB${i}_pPb_pT8to10.root"
#done

#for i in 3 ; do
#  hadd dataMB${i}_Pbp_pT8to10.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_8.0_10.0) &> dataMB${i}_Pbp_pT8to10.log
#  echo "Done dataMB${i}_Pbp_pT8to10.root"
#done

#for i in {12..20} ; do
#  hadd dataMB${i}_Pbp_pT8to10.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_8.0_10.0) &> dataMB${i}_Pbp_pT8to10.log
#  echo "Done dataMB${i}_Pbp_pT8to10.root"
#done

#for i in 11 ; do
#  hadd dataMB${i}_Pbp_pT8to10.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_8.0_10.0) &> dataMB${i}_Pbp_pT8to10.log
#  echo "Done dataMB${i}_Pbp_pT8to10.root"
#done

#for i in 12 ; do
#  hadd dataMB${i}_Pbp_pT8to10.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_8.0_10.0) &> dataMB${i}_Pbp_pT8to10.log
#  echo "Done dataMB${i}_Pbp_pT8to10.root"
#done

#for i in 9 10 ; do
#  hadd dataMB${i}_Pbp_pT8to10.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_8.0_10.0) &> dataMB${i}_Pbp_pT8to10.log
#  echo "Done dataMB${i}_Pbp_pT8to10.root"
#done

#for i in {1..4} ; do
#  hadd dataMB${i}_pPb_pT6to8.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_pPb/pT_6.0_8.0) &> dataMB${i}_pPb_pT6to8.log
#  echo "Done dataMB${i}_pPb_pT6to8.root"
#done

#for i in {5..6} ; do
#  hadd dataMB${i}_pPb_pT6to8.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_pPb/pT_6.0_8.0) &> dataMB${i}_pPb_pT6to8.log
#  echo "Done dataMB${i}_pPb_pT6to8.root"
#done

#for i in {7..8} ; do
#  hadd dataMB${i}_pPb_pT6to8.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_pPb/pT_6.0_8.0) &> dataMB${i}_pPb_pT6to8.log
#  echo "Done dataMB${i}_pPb_pT6to8.root"
#done

#for i in {1..4} ; do
#  hadd dataMB${i}_Pbp_pT6to8.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_6.0_8.0) &> dataMB${i}_Pbp_pT6to8.log
#  echo "Done dataMB${i}_Pbp_pT6to8.root"
#done

#for i in {4..8} ; do
#  hadd dataMB${i}_Pbp_pT6to8.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_6.0_8.0) &> dataMB${i}_Pbp_pT6to8.log
#  echo "Done dataMB${i}_Pbp_pT6to8.root"
#done

#for i in {9..12} ; do
#  hadd dataMB${i}_Pbp_pT6to8.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_6.0_8.0) &> dataMB${i}_Pbp_pT6to8.log
#  echo "Done dataMB${i}_Pbp_pT6to8.root"
#done

#for i in {13..16} ; do
#  hadd dataMB${i}_Pbp_pT6to8.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_6.0_8.0) &> dataMB${i}_Pbp_pT6to8.log
#  echo "Done dataMB${i}_Pbp_pT6to8.root"
#done

#for i in {17..20} ; do
#  hadd dataMB${i}_Pbp_pT6to8.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_6.0_8.0) &> dataMB${i}_Pbp_pT6to8.log
#  echo "Done dataMB${i}_Pbp_pT6to8.root"
#done

#for i in {1..3} ; do
#  hadd dataMB${i}_Pbp_pT3to4.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_3.0_4.0) &> dataMB${i}_Pbp_pT3to4.log
#  echo "Done dataMB${i}_Pbp_pT3to4.root"
#done

#for i in {4..6} ; do
#  hadd dataMB${i}_Pbp_pT3to4.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_3.0_4.0) &> dataMB${i}_Pbp_pT3to4.log
#  echo "Done dataMB${i}_Pbp_pT3to4.root"
#done

#for i in 4 ; do
#  hadd dataMB${i}_Pbp_pT3to4.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_3.0_4.0) &> dataMB${i}_Pbp_pT3to4.log
#  echo "Done dataMB${i}_Pbp_pT3to4.root"
#done

#for i in {7..9} ; do
#  hadd dataMB${i}_Pbp_pT3to4.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_3.0_4.0) &> dataMB${i}_Pbp_pT3to4.log
#  echo "Done dataMB${i}_Pbp_pT3to4.root"
#done

#for i in {10..12} ; do
#  hadd dataMB${i}_Pbp_pT3to4.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_3.0_4.0) &> dataMB${i}_Pbp_pT3to4.log
#  echo "Done dataMB${i}_Pbp_pT3to4.root"
#done

#for i in {13..15} ; do
#  hadd dataMB${i}_Pbp_pT3to4.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_3.0_4.0) &> dataMB${i}_Pbp_pT3to4.log
#  echo "Done dataMB${i}_Pbp_pT3to4.root"
#done

#for i in {16..18} ; do
#  hadd dataMB${i}_Pbp_pT3to4.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_3.0_4.0) &> dataMB${i}_Pbp_pT3to4.log
#  echo "Done dataMB${i}_Pbp_pT3to4.root"
#done

#for i in 20 ; do
#  hadd dataMB${i}_Pbp_pT3to4.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_Pbp/pT_3.0_4.0) &> dataMB${i}_Pbp_pT3to4.log
#  echo "Done dataMB${i}_Pbp_pT3to4.root"
#done

#for i in {1..3} ; do
#  hadd dataMB${i}_pPb_pT3to4.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_pPb/pT_3.0_4.0) &> dataMB${i}_pPb_pT3to4.log
#  echo "Done dataMB${i}_pPb_pT3to4.root"
#done

#for i in {4..6} ; do
#  hadd dataMB${i}_pPb_pT3to4.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_pPb/pT_3.0_4.0) &> dataMB${i}_pPb_pT3to4.log
#  echo "Done dataMB${i}_pPb_pT3to4.root"
#done

#for i in {7..8} ; do
#  hadd dataMB${i}_pPb_pT3to4.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_pPb/pT_3.0_4.0) &> dataMB${i}_pPb_pT3to4.log
#  echo "Done dataMB${i}_pPb_pT3to4.root"
#done

#for i in 2 ; do
#  hadd dataMB${i}_pPb_pT3to4.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataMB${i}_pPb/pT_3.0_4.0) &> dataMB${i}_pPb_pT3to4.log
#  echo "Done dataMB${i}_pPb_pT3to4.root"
#done

#for i in 1 ; do
#  hadd dataHM${i}_pPb_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_pPb/pT_4.0_6.0) &> dataHM${i}_pPb_pT4to6.log
#  echo "Done dataHM${i}_pPb_pT4to6.root"
#done

#for i in 2 ; do
#  hadd dataHM${i}_pPb_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_pPb/pT_4.0_6.0) &> dataHM${i}_pPb_pT4to6.log
#  echo "Done dataHM${i}_pPb_pT4to6.root"
#done

#for i in 3 ; do
#  hadd dataHM${i}_pPb_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_pPb/pT_4.0_6.0) &> dataHM${i}_pPb_pT4to6.log
#  echo "Done dataHM${i}_pPb_pT4to6.root"
#done

#for i in 4 ; do
#  hadd dataHM${i}_pPb_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_pPb/pT_4.0_6.0) &> dataHM${i}_pPb_pT4to6.log
#  echo "Done dataHM${i}_pPb_pT4to6.root"
#done

#for i in 5 ; do
#  hadd dataHM${i}_pPb_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_pPb/pT_4.0_6.0) &> dataHM${i}_pPb_pT4to6.log
#  echo "Done dataHM${i}_pPb_pT4to6.root"
#done

#for i in 6 ; do
#  hadd dataHM${i}_pPb_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_pPb/pT_4.0_6.0) &> dataHM${i}_pPb_pT4to6.log
#  echo "Done dataHM${i}_pPb_pT4to6.root"
#done

#for i in {1..2} ; do
#  hadd dataHM${i}_Pbp_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_Pbp/pT_4.0_6.0) &> dataHM${i}_Pbp_pT4to6.log
#  echo "Done dataHM${i}_Pbp_pT4to6.root"
#done

#for i in {4..6} ; do
#  hadd dataHM${i}_Pbp_pT4to6.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_Pbp/pT_4.0_6.0) &> dataHM${i}_Pbp_pT4to6.log
#  echo "Done dataHM${i}_Pbp_pT4to6.root"
#done

#for i in {1..3} ; do
#  hadd dataHM${i}_Pbp_pT6to8.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_Pbp/pT_6.0_8.0) &> dataHM${i}_Pbp_pT6to8.log
#  echo "Done dataHM${i}_Pbp_pT6to8.root"
#done

#for i in {4..6} ; do
#  hadd dataHM${i}_Pbp_pT6to8.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_Pbp/pT_6.0_8.0) &> dataHM${i}_Pbp_pT6to8.log
#  echo "Done dataHM${i}_Pbp_pT6to8.root"
#done

#for i in {1..3} ; do
#  hadd dataHM${i}_pPb_pT6to8.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_pPb/pT_6.0_8.0) &> dataHM${i}_pPb_pT6to8.log
#  echo "Done dataHM${i}_pPb_pT6to8.root"
#done

for i in {4..6} ; do
  hadd dataHM${i}_pPb_pT6to8.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_pPb/pT_6.0_8.0) &> dataHM${i}_pPb_pT6to8.log
  echo "Done dataHM${i}_pPb_pT6to8.root"
done
