#!/usr/bin/bash
#for i in {2..6} ; do
#  hadd dataHM${i}_pPb_pT3to4.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_pPb/pT_3.0_4.0) &> dataHM${i}_pPb_pT3to4.log
#  echo "Done dataHM${i}_pPb_pT3to4.root"
#done

for i in {1..6} ; do
  hadd dataHM${i}_Pbp_pT3to4.root $(xrdfs root://cmseos.fnal.gov ls -u /store/user/yousen/RiceHIN/OpenHF2020_LamCKsP/AppMVAv2/dataHM${i}_Pbp/pT_3.0_4.0) &> dataHM${i}_Pbp_pT3to4.log
  echo "Done dataHM${i}_Pbp_pT3to4.root"
done
